import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { HomeAboutComponent } from './home/home-about/home-about.component';
import { HomeRoomsComponent } from './home/home-rooms/home-rooms.component';
import { HomeServicesComponent } from './home/home-services/home-services.component';
import { HomeCtaComponent } from './home/home-cta/home-cta.component';



@NgModule({
  declarations: [
    HomeComponent,
    AboutComponent,
    ContactComponent,
    HomeAboutComponent,
    HomeRoomsComponent,
    HomeServicesComponent,
    HomeCtaComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    HomeComponent,
    AboutComponent,
    ContactComponent
  ]
})
export class PagesModule { }
